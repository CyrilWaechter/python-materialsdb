"""Map resolved payloads onto an ifcopenshell file via ifcopenshell.api.

Pure ifcopenshell (no bpy/bonsai imports) so CI can test it directly.
api handles GlobalId/OwnerHistory and keeps entities schema-valid; kwargs
target the 0.9 api (add_layer takes no thickness — edit_layer sets it;
root.create_entity takes ifc_class=)."""

import math
import re

import ifcopenshell.api
import ifcopenshell.util.element
import ifcopenshell.util.representation

_THERMAL_TRANSMITTANCE_PSET = {
    "IfcWallType": "Pset_WallCommon",
    "IfcSlabType": "Pset_SlabCommon",
    "IfcRoofType": "Pset_RoofCommon",
}


def _write_thermal_transmittance(file, target, u_value: float) -> bool:
    """Find-or-create the type's Common pset and set ThermalTransmittance."""
    pset_name = _THERMAL_TRANSMITTANCE_PSET.get(target.is_a())
    if pset_name is None:
        return False
    found = ifcopenshell.util.element.get_pset(target, name=pset_name)
    if found is None:
        pset = ifcopenshell.api.run("pset.add_pset", file, product=target, name=pset_name)
    else:
        pset = file.by_id(found["id"])
    ifcopenshell.api.run("pset.edit_pset", file, pset=pset, properties={"ThermalTransmittance": u_value})
    return True


def _material_id_of(material) -> str | None:
    return ifcopenshell.util.element.get_psets(material).get("materialsdb", {}).get("material_id")


def _org_layer_id_of(material) -> str | None:
    return ifcopenshell.util.element.get_psets(material).get("materialsdb.org_layer", {}).get("layer_id")


def existing_materials_by_id(file):
    """material_id -> first IfcMaterial carrying a matching materialsdb pset."""
    found = {}
    for material in file.by_type("IfcMaterial"):
        material_id = _material_id_of(material)
        if material_id is not None and material_id not in found:
            found[material_id] = material
    return found


def _existing_keys(file):
    """(material_id, layer_id | None) -> IfcMaterial already present, from the
    materialsdb identity + org_layer psets."""
    found = {}
    for material in file.by_type("IfcMaterial"):
        material_id = _material_id_of(material)
        if material_id is not None:
            found.setdefault((material_id, _org_layer_id_of(material)), material)
    return found


def _add_identity_pset(file, material, identity):
    pset = ifcopenshell.api.run("pset.add_pset", file, product=material, name="materialsdb")
    ifcopenshell.api.run(
        "pset.edit_pset",
        file,
        pset=pset,
        properties={
            "material_id": identity["material_id"],
            "company_id": identity.get("company_id") or "",
            "company": identity.get("company") or "",
        },
    )


def _add_property_psets(file, material, psets):
    for pset_name, props in (psets or {}).items():
        pset = ifcopenshell.api.run("pset.add_pset", file, product=material, name=str(pset_name))
        ifcopenshell.api.run("pset.edit_pset", file, pset=pset, properties=props)


_OUR_STYLE_NAME = re.compile(r"^(?:color \d+|category .+)$")


def _resolved_style(material_entry):
    """(name, (r, g, b) in 0..1) for a material entry.

    Prefers the server-resolved `style_name`/`style_color` (producer colour or
    the active scheme's category colour); falls back to the legacy producer
    `color` for payloads produced by an older server."""
    name = material_entry.get("style_name")
    rgb = material_entry.get("style_color")
    if name and rgb:
        return name, tuple(float(component) for component in rgb)
    color = material_entry.get("color")
    if not color:
        return None
    color = int(color)
    return f"color {color}", (((color >> 16) & 255) / 255, ((color >> 8) & 255) / 255, (color & 255) / 255)


def _valid_style_names(material):
    """Names of the valid (non-empty) surface styles assigned to a material."""
    names = []
    for representation in material.HasRepresentation or ():
        for styled in representation.Representations or ():
            for item in styled.Items or ():
                if not item.is_a("IfcStyledItem"):
                    continue
                for style in item.Styles or ():
                    if style.is_a("IfcSurfaceStyle") and style.Styles:
                        names.append(style.Name)
                    elif style.is_a("IfcPresentationStyleAssignment"):
                        names.extend(
                            nested.Name
                            for nested in style.Styles or ()
                            if nested.is_a("IfcSurfaceStyle") and nested.Styles
                        )
    return names


def _should_style(material):
    """True when a material has no valid style, or only styles we created (so
    the materialsdb colour may be refreshed); a third-party style is kept."""
    names = _valid_style_names(material)
    if not names:
        return True
    return all(name and _OUR_STYLE_NAME.match(name) for name in names)


def _apply_style(file, material_entry, material):
    """Best-effort schema-valid material styling; needs a representation
    context (bonsai files have one, scratch CI files do not).

    The IfcSurfaceStyle is built in one shot: creating it via
    style.add_style leaves Styles=$ (invalid, SET [1:?]) until
    add_surface_style runs, so a mid-way failure would persist an entity
    that crashes ifcopenshell's style loader on the next open. Existing
    styles with NULL/empty Styles are ignored on reuse for the same
    reason."""
    resolved = _resolved_style(material_entry)
    if resolved is None:
        return
    name, rgb = resolved
    try:
        context = ifcopenshell.util.representation.get_context(file, "Model", "Body", "MODEL_VIEW")
        if context is None:
            context = ifcopenshell.util.representation.get_context(file, "Model")
        if context is None:
            contexts = file.by_type("IfcRepresentationContext")
            if not contexts:
                return
            context = contexts[0]
        styles = {}
        for style in file.by_type("IfcSurfaceStyle"):
            if style.Styles:  # never reuse a malformed (NULL/empty Styles) style
                styles.setdefault(style.Name, style)
        style = styles.get(name)
        if style is None:
            shading = file.create_entity(
                "IfcSurfaceStyleShading",
                SurfaceColour=file.create_entity("IfcColourRgb", Name=None, Red=rgb[0], Green=rgb[1], Blue=rgb[2]),
            )
            style = file.create_entity("IfcSurfaceStyle", Name=name, Side="BOTH", Styles=[shading])
        ifcopenshell.api.run("style.assign_material_style", file, material=material, style=style, context=context)
    except Exception:  # noqa: BLE001, S110 - cosmetic; never fail the insert
        pass


def _find_material_by_name(file, name):
    if not name:
        return None
    return next((m for m in file.by_type("IfcMaterial") if m.Name == name), None)


def _create_placeholder_material(file, placeholder):
    material = ifcopenshell.api.run("material.add_material", file, name=str(placeholder.get("name") or "(unnamed)"))
    lambda_value = placeholder.get("lambda_value")
    if lambda_value:
        thermal = ifcopenshell.api.run("pset.add_pset", file, product=material, name="Pset_MaterialThermal")
        ifcopenshell.api.run(
            "pset.edit_pset", file, pset=thermal, properties={"ThermalConductivity": float(lambda_value)}
        )
    return material


def apply_add_materials(file, payload) -> int:
    """Create IfcMaterial (+ identity/property psets, layer + set, style) per
    payload entry. Entries whose (material_id, layer_id) key already exists are
    re-styled when their colour is ours or missing. Returns the number created."""
    existing = _existing_keys(file)
    created = 0
    for entry in payload.get("materials") or []:
        identity = entry["identity"]
        layer = entry.get("layer") or {}
        org_layer_id = (entry.get("psets") or {}).get("materialsdb.org_layer", {}).get("layer_id")
        key = (identity["material_id"], layer.get("layer_id") or org_layer_id)
        if key in existing:
            if _should_style(existing[key]):
                _apply_style(file, entry, existing[key])
            continue
        material = ifcopenshell.api.run(
            "material.add_material",
            file,
            name=str(entry["name"]),
            category=str(entry.get("category") or ""),
            description=str(entry.get("description") or ""),
        )
        _add_identity_pset(file, material, identity)
        _add_property_psets(file, material, entry.get("psets"))
        if layer:
            thickness = float(layer["thick_m"])
            label = f"{entry['name']} | {round(thickness * 1000)}mm"
            layer_set = ifcopenshell.api.run(
                "material.add_material_set", file, name=label, set_type="IfcMaterialLayerSet"
            )
            ifc_layer = ifcopenshell.api.run("material.add_layer", file, layer_set=layer_set, material=material)
            ifcopenshell.api.run(
                "material.edit_layer",
                file,
                layer=ifc_layer,
                attributes={"LayerThickness": thickness, "Name": label, "Description": str(layer["layer_id"])},
            )
        _apply_style(file, entry, material)
        existing[key] = material
        created += 1
    return created


def apply_add_construction(file, payload) -> dict:
    """Upsert a construction as typed element(s) + IfcMaterialLayerSet.

    Types are created if missing and kept if present; a re-send rebuilds the
    existing set IN PLACE (same entity, old layers removed) and re-assigns
    all targets onto it. Generic usage shares ONE set across all types via a
    single IfcRelAssociatesMaterial. Materials are found by their materialsdb
    identity pset or created minimally (identity + style, no per-layer
    psets). Placeholder layers (material_id None) re-attach a model material
    by name or create one, carrying a Pset_MaterialThermal when a λ is
    given. A `u_values` map (per type class) writes `ThermalTransmittance`
    into the matching `Pset_<Type>Common` pset, created or edited in place."""
    construction = payload["construction"]
    summary = {"types_created": 0, "sets_updated": 0, "materials_created": 0, "placeholders_matched": 0}

    known = existing_materials_by_id(file)
    layers = []
    for layer in construction["layers"]:
        if layer.get("placeholder") is not None:
            name = str(layer["placeholder"].get("name") or "")
            material = _find_material_by_name(file, name)
            if material is None:
                material = _create_placeholder_material(file, layer["placeholder"])
                summary["materials_created"] += 1
            else:
                summary["placeholders_matched"] += 1
            layers.append((layer, material))
            continue
        entry = layer["material"]
        material = known.get(layer["material_id"])
        if material is None:
            material = ifcopenshell.api.run(
                "material.add_material",
                file,
                name=str(entry["name"]),
                category=str(entry.get("category") or ""),
                description=str(entry.get("description") or ""),
            )
            _add_identity_pset(file, material, entry["identity"])
            known[layer["material_id"]] = material
            summary["materials_created"] += 1
        # style reused materials too: an earlier push (or a pre-fix session)
        # may have left them colourless, and users expect the colour to show
        if _should_style(material):
            _apply_style(file, entry, material)
        layers.append((layer, material))

    name = str(construction["name"])
    targets = []
    for cls in construction["types"]:
        match = [t for t in file.by_type(cls) if t.Name == name]
        if match:
            targets.append(match[0])
        else:
            targets.append(ifcopenshell.api.run("root.create_entity", file, ifc_class=cls, name=name))
            summary["types_created"] += 1

    the_set = None
    for target in targets:
        for association in target.HasAssociations or ():
            relating = getattr(association, "RelatingMaterial", None)
            if relating is not None and relating.is_a("IfcMaterialLayerSet"):
                the_set = relating
                break
        if the_set is not None:
            break

    if the_set is None:
        the_set = ifcopenshell.api.run("material.add_material_set", file, name=name, set_type="IfcMaterialLayerSet")
    else:
        summary["sets_updated"] += 1
        for stale in list(the_set.MaterialLayers or ()):
            ifcopenshell.api.run("material.remove_layer", file, layer=stale)

    for layer, material in layers:
        ifc_layer = ifcopenshell.api.run("material.add_layer", file, layer_set=the_set, material=material)
        mm = round(float(layer["thickness_m"]) * 1000)
        entry = layer.get("material")
        if entry is not None:
            label = f"{entry['name']} | {mm}mm"
            description = str(layer["material_id"])
        else:
            label = f"{(layer.get('placeholder') or {}).get('name') or '(unnamed)'} | {mm}mm"
            description = ""
        ifcopenshell.api.run(
            "material.edit_layer",
            file,
            layer=ifc_layer,
            attributes={
                "LayerThickness": float(layer["thickness_m"]),
                "Name": label,
                "Description": description,
            },
        )

    for target in targets:
        for association in list(target.HasAssociations or ()):
            if association.is_a("IfcRelAssociatesMaterial"):
                file.remove(association)
    ifcopenshell.api.run(
        "material.assign_material",
        file,
        products=[t for t in targets if t is not None],
        type="IfcMaterialLayerSet",
        material=the_set,
    )
    raw_u_values = construction.get("u_values")
    u_values = raw_u_values if isinstance(raw_u_values, dict) else {}
    written = 0
    for target in targets:
        u_value = u_values.get(target.is_a())
        if (
            isinstance(u_value, (int, float))
            and not isinstance(u_value, bool)
            and math.isfinite(float(u_value))
            and _write_thermal_transmittance(file, target, float(u_value))
        ):
            written += 1
    summary["psets_written"] = written
    return summary
