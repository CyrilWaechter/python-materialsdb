"""materialsdb listener: receive material and construction pushes from the
local materialsdb picker.

The bpy surface is intentionally thin: a timer polls the local GUI server
and hands payloads to an undoable operator (tool.Ifc.Operator); all IFC work
goes through insert.py (pure ifcopenshell.api, CI-tested)."""

import atexit
import os
import shutil
import subprocess
import tempfile
import typing
import webbrowser

import bpy
from bonsai import tool

from . import insert
from .discovery import ListenerClient, _cache_folder, _model_material_map, clear_gui_info, read_gui_info
from .read_construction import ReadError, read_construction_from_element

_CLIENT = None
_PENDING = None
_SERVER_PROC = None
_SERVER_LOG = None

# Entry point for the server subprocess. Spelled out instead of `-m
# materialsdb.gui`: under a VSCode/debugpy-launched Blender the injected child
# environment can make `-m` resolve a stale `materialsdb` (without `gui`),
# while the same import works via -c.
_SERVER_CODE = "from materialsdb.gui.__main__ import main; main()"


class MATERIALSDB_OT_apply_push(bpy.types.Operator, tool.Ifc.Operator):
    bl_idname = "materialsdb.apply_push"
    bl_label = "materialsdb apply push"
    bl_description = "Apply a pushed materialsdb payload to the open IFC model"
    # No UNDO flag: the WM does not push a titled step for operators invoked
    # from a timer, so the mutations would fold into a neighboring undo step.
    # The timer pushes an explicit, titled ed.undo_push instead.
    bl_options: typing.ClassVar[set[str]] = {"REGISTER"}

    def _execute(self, context):
        global _PENDING
        payload, _PENDING = _PENDING, None
        if payload is None:
            return
        if tool.Ifc.get() is None:
            _CLIENT.report("error", "no IFC model open in Bonsai")
            return
        action = payload.get("action")
        if action == "add_materials":
            summary = {}
            count = insert.apply_add_materials(tool.Ifc.get(), payload, summary=summary)
            _sync_style_materials(tool.Ifc.get())
            _retarget_style_materials(tool.Ifc.get(), summary.get("style_swaps"))
            _CLIENT.report("applied", _safety_net(f"{count} material(s) added", summary))
            _send_model_map()
        elif action == "add_construction":
            result = insert.apply_add_construction(tool.Ifc.get(), payload)
            _link_pushed_types(tool.Ifc.get(), payload["construction"])
            _sync_style_materials(tool.Ifc.get())
            _retarget_style_materials(tool.Ifc.get(), result.get("style_swaps"))
            _reload_construction_instances(tool.Ifc.get(), payload["construction"])
            report = (
                f"{result['types_created']} type(s) created, {result['sets_updated']} set(s) updated, "
                f"{result['materials_created']} material(s) created, "
                f"{result['placeholders_matched']} placeholder(s) matched, "
                f"{result['psets_written']} thermal pset(s) written"
            )
            _CLIENT.report("applied", _safety_net(report, result))
            _send_model_map()
        elif action == "restyle":
            summary = {}
            count = insert.apply_restyle(tool.Ifc.get(), payload, summary=summary)
            _sync_style_materials(tool.Ifc.get())
            _retarget_style_materials(tool.Ifc.get(), summary.get("style_swaps"))
            detail = f"{count} material(s) restyled"
            kept, missing = sorted(set(summary["kept_styles"])), sorted(set(summary["missing"]))
            if kept:
                detail += f", {len(kept)} kept (foreign style)"
            if missing:
                detail += f", {len(missing)} not in model"
            _CLIENT.report("applied", detail)
        else:
            _CLIENT.report("error", f"unknown action: {action}")


def _model_path():
    return str(tool.Ifc.get_path() or "")


def _safety_net(report, summary):
    """Append the push safety net: how many changed materials were not opted in
    (left untouched), how many replacement(s) failed, and how many update
    targets could no longer be found in the model, so a push never silently
    drops work."""
    summary = summary or {}
    skipped = summary.get("changed_skipped") or []
    if skipped:
        report += f"; {len(skipped)} changed material(s) left unchanged"
    failed = summary.get("replace_failed") or []
    if failed:
        report += f"; {len(failed)} replacement(s) failed"
    missing = summary.get("update_missing") or []
    if missing:
        report += f"; {len(missing)} update target(s) not found in the model"
    return report


def _send_model_map():
    """Report the open model's material map to the GUI (status/changes)."""
    try:
        file = tool.Ifc.get()
        materials = _model_material_map(file) if file is not None else {}
        _CLIENT.send_model_map(_model_path(), materials)
    except Exception:  # noqa: BLE001, S110 - reporting is best-effort; never break the poll loop or a push
        pass


def _undo_label(payload):
    action = payload.get("action")
    if action == "add_construction":
        return f"materialsdb: add construction '{payload['construction'].get('name', '')}'"
    if action == "add_materials":
        return f"materialsdb: add {len(payload.get('materials') or [])} material(s)"
    if action == "restyle":
        return f"materialsdb: restyle {len(payload.get('materials') or [])} material(s)"
    return "materialsdb: apply push"


def _link_pushed_types(file, construction):
    """Bonsai's outliner is the stock Blender outliner: an IFC element shows
    only when a Blender object exists for it, placed in the IfcTypeProduct
    collection. Mirror bonsai's own type-creation flow (link + name +
    collector) for pushed types; idempotent via get_object."""
    for cls in construction["types"]:
        for element in file.by_type(cls):
            if element.Name != construction["name"]:
                continue
            if tool.Ifc.get_object(element) is not None:
                continue
            obj = bpy.data.objects.new(element.Name, None)
            tool.Ifc.link(element, obj)
            tool.Root.set_object_name(obj, element)
            tool.Collector.assign(obj)
            bpy.context.view_layer.update()


def _sync_style_materials(file):
    """Give live-pushed IfcSurfaceStyle entities a Bonsai Blender material.

    Bonsai builds its Blender material and the IfcStore link only while
    importing (import_ifc.create_style); a style added to an already-open model
    has none, so the viewport layer slicing gets no material (no colour) and
    the style editor fails on the missing material. Mirror that import step
    here: create + link + colour, best-effort per style."""
    for style in file.by_type("IfcSurfaceStyle"):
        try:
            blender_material = tool.Ifc.get_object(style)
            if blender_material is None:
                blender_material = bpy.data.materials.new(style.Name or str(style.id()))
                blender_material.use_fake_user = True
                tool.Ifc.link(style, blender_material)
            tool.Style.get_material_style_props(blender_material).active_style_type = "Shading"
            tool.Style.switch_shading(blender_material, "Shading")
        except Exception:  # noqa: BLE001, S110 - cosmetic; never fail the push
            pass


def _reload_construction_instances(file, construction):
    """Reload the occurrences of a pushed construction's types from IFC.

    `apply_add_construction` rebuilds an existing type's layer set in place, so
    the occurrences' Blender meshes keep their old material slots until
    reloaded. New types have no occurrences yet."""
    name = str(construction.get("name") or "")
    objects = []
    for cls in construction.get("types") or []:
        for target in file.by_type(cls):
            if target.Name != name:
                continue
            for rel in file.get_inverse(target):
                if not rel.is_a("IfcRelDefinesByType"):
                    continue
                for element in rel.RelatedObjects or ():
                    obj = tool.Ifc.get_object(element)
                    if obj is not None:
                        objects.append(obj)
    if not objects:
        return
    try:
        tool.Geometry.reload_representation(objects)
    except Exception:  # noqa: BLE001, S110 - cosmetic; never fail the push
        pass


def _retarget_style_materials(file, swaps):
    """Repoint loaded objects from a superseded style's Blender material to its
    replacement's. Bonsai copies ``tool.Ifc.get_object(style)`` into mesh/curve
    slots at load time, so swapping a material to a different style entity
    otherwise leaves the viewport on the old colour even though the IFC is
    correct. Only swaps whose old style is no longer used by any IfcMaterial are
    recorded, so a still-shared style is never hijacked."""
    for old_style, new_style in swaps or ():
        old_material = tool.Ifc.get_object(old_style)
        new_material = tool.Ifc.get_object(new_style)
        if old_material is None or new_material is None or old_material is new_material:
            continue
        for obj in bpy.data.objects:
            data = getattr(obj, "data", None)
            materials = getattr(data, "materials", None)
            if not materials:
                continue
            for index, material in enumerate(materials):
                if material is old_material:
                    materials[index] = new_material


def _poll_timer():
    global _CLIENT, _PENDING  # noqa: PLW0602
    if _CLIENT is None:
        return None  # listener stopped: unregister the timer
    try:
        path = _model_path()
        if path != _CLIENT.registered_path:
            _CLIENT.register(path)
            _send_model_map()
        payload = _CLIENT.poll()
        if payload is not None:
            _PENDING = payload
            try:
                bpy.ops.materialsdb.apply_push()
            except Exception as err:  # noqa: BLE001 - report; never kill the poll loop
                try:
                    _CLIENT.report("error", str(err))
                except Exception:  # noqa: BLE001, S110
                    pass
            else:
                # titled, isolated undo step (the WM pushes none for
                # timer-invoked operators); bookkeeping is best-effort
                try:
                    bpy.ops.ed.undo_push(message=_undo_label(payload))
                except Exception:  # noqa: BLE001, S110
                    pass
    except Exception as err:  # noqa: BLE001 - a failed push must not kill the timer
        try:
            _CLIENT.report("error", str(err))
        except Exception:  # noqa: BLE001, S110
            pass
    return 1.0


def _prefs():
    return getattr(bpy.context.preferences.addons.get(__package__), "preferences", None)


def _find_python():
    """The configured interpreter, else autodiscover python3/python/py."""
    prefs = _prefs()
    if prefs is not None and prefs.interpreter.strip():
        return prefs.interpreter.strip()
    return shutil.which("python3") or shutil.which("python") or shutil.which("py")


def _server_port():
    prefs = _prefs()
    return prefs.port if prefs is not None else 0


def _server_url():
    info = read_gui_info()
    return f"http://127.0.0.1:{info[0]}" if info else None


def _server_alive(url):
    import urllib.request

    try:
        urllib.request.urlopen(url, timeout=2)
    except Exception:  # noqa: BLE001 - dead/stale server is the normal case
        return False
    return True


def _kill_server():
    global _SERVER_PROC, _SERVER_LOG
    if _SERVER_PROC is not None:
        _SERVER_PROC.terminate()
        try:
            _SERVER_PROC.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _SERVER_PROC.kill()
        _SERVER_PROC = None
    if _SERVER_LOG is not None:
        try:
            _SERVER_LOG.close()
        except OSError:
            pass
        _SERVER_LOG = None


def _child_cwd():
    """Run the server from a neutral directory: a `materialsdb` folder in the
    working directory (e.g. the repo root, or a VSCode workspace) would shadow
    the installed package on the child's sys.path[0]."""
    return tempfile.gettempdir()


def _child_env():
    """Environment for the server subprocess. PYTHONHOME is dropped: a
    Blender/VSCode process may carry one for its bundled Python, which breaks a
    system interpreter. PYTHONPATH is kept so a dev checkout on it still wins."""
    env = dict(os.environ)
    env.pop("PYTHONHOME", None)
    return env


def _server_log_path():
    folder = _cache_folder()
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "gui.log"


def _server_log_tail(lines=10):
    try:
        text = _server_log_path().read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    return "\n".join(text.strip().splitlines()[-lines:])


class MATERIALSDB_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    interpreter: bpy.props.StringProperty(
        name="Python interpreter",
        description="Interpreter with python-materialsdb installed (empty = autodiscover python3/python/py on PATH)",
        subtype="FILE_PATH",
    )
    port: bpy.props.IntProperty(name="Port", description="0 lets the server pick a free port", default=0)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "interpreter")
        layout.prop(self, "port")
        layout.label(text="Requires: pip install python-materialsdb (in that interpreter)")


class MATERIALSDB_OT_start_server(bpy.types.Operator):
    bl_idname = "materialsdb.start_server"
    bl_label = "Start server & open picker"
    bl_description = "Start the local materialsdb GUI server and open it in your browser"
    bl_options: typing.ClassVar[set[str]] = {"REGISTER"}

    def execute(self, context):
        global _SERVER_PROC, _SERVER_LOG
        url = _server_url()
        if url is not None and _server_alive(url):
            webbrowser.open(url)
            self.report({"INFO"}, f"server already running: {url}")
            return {"FINISHED"}
        _kill_server()
        clear_gui_info()
        python = _find_python()
        if python is None:
            self.report({"ERROR"}, "no python interpreter found; set one in the add-on preferences")
            return {"CANCELLED"}
        try:
            check = subprocess.run(
                [python, "-c", "import materialsdb.gui"],
                capture_output=True,
                text=True,
                timeout=60,
                check=False,
                cwd=_child_cwd(),
                env=_child_env(),
            )
        except (subprocess.SubprocessError, OSError) as err:
            self.report({"ERROR"}, f"could not run {python}: {err}")
            return {"CANCELLED"}
        if check.returncode != 0:
            lines = (check.stderr or check.stdout or "").strip().splitlines()
            detail = lines[-1] if lines else f"exit code {check.returncode}"
            self.report(
                {"ERROR"},
                f"{python} cannot import materialsdb.gui: {detail} — install/upgrade "
                "python-materialsdb there, or set another interpreter in the add-on preferences",
            )
            return {"CANCELLED"}
        args = [python, "-c", _SERVER_CODE, "--no-browser"]
        if _server_port():
            args += ["--port", str(_server_port())]
        # handle kept open for the process lifetime; closed by _kill_server()
        _SERVER_LOG = open(_server_log_path(), "w", encoding="utf-8")  # noqa: SIM115
        _SERVER_PROC = subprocess.Popen(
            args,
            stdout=subprocess.DEVNULL,
            stderr=_SERVER_LOG,
            cwd=_child_cwd(),
            env=_child_env(),
        )
        atexit.register(_kill_server)
        import time

        deadline = time.time() + 15
        while time.time() < deadline:
            url = _server_url()
            if url is not None:
                break
            time.sleep(0.2)
        if url is None:
            self.report(
                {"ERROR"},
                f"server did not start — log: {_server_log_path()}\n{_server_log_tail()}",
            )
            _kill_server()
            return {"CANCELLED"}
        webbrowser.open(url)
        self.report({"INFO"}, f"server started: {url}")
        return {"FINISHED"}


class MATERIALSDB_OT_stop_server(bpy.types.Operator):
    bl_idname = "materialsdb.stop_server"
    bl_label = "Stop server"
    bl_description = "Stop the local materialsdb GUI server"
    bl_options: typing.ClassVar[set[str]] = {"REGISTER"}

    def execute(self, context):
        if _SERVER_PROC is None:
            self.report({"INFO"}, "server not started from here")
            return {"FINISHED"}
        _kill_server()
        clear_gui_info()
        self.report({"INFO"}, "server stopped")
        return {"FINISHED"}


class MATERIALSDB_OT_toggle_listener(bpy.types.Operator):
    bl_idname = "materialsdb.toggle_listener"
    bl_label = "materialsdb listener"
    bl_description = "Start or stop receiving pushes from the local materialsdb picker"
    bl_options: typing.ClassVar[set[str]] = {"REGISTER"}

    def execute(self, context):
        global _CLIENT
        if _CLIENT is None:
            _CLIENT = ListenerClient()
            try:
                _CLIENT.register(_model_path())
            except Exception as err:  # noqa: BLE001
                _CLIENT = None
                self.report({"ERROR"}, f"materialsdb-gui not reachable: {err}")
                return {"CANCELLED"}
            bpy.app.timers.register(_poll_timer, persistent=True)
            _send_model_map()
            self.report({"INFO"}, "materialsdb listener started")
        else:
            _CLIENT = None
            self.report({"INFO"}, "materialsdb listener stopped")
        return {"FINISHED"}


class MATERIALSDB_OT_send_construction(bpy.types.Operator):
    bl_idname = "materialsdb.send_construction"
    bl_label = "materialsdb send construction"
    bl_description = "Push the active object's type layer set to the composer (read-only)"
    bl_options: typing.ClassVar[set[str]] = {"REGISTER"}

    def execute(self, context):
        obj = context.active_object
        element = tool.Ifc.get_entity(obj) if obj is not None else None
        if element is None:
            self.report({"ERROR"}, "select an IFC element")
            return {"CANCELLED"}
        try:
            construction = read_construction_from_element(element)
        except ReadError as err:
            self.report({"ERROR"}, str(err))
            return {"CANCELLED"}
        try:
            ListenerClient().send_to_composer(construction)
        except RuntimeError as err:
            self.report({"ERROR"}, str(err))
            return {"CANCELLED"}
        except Exception as err:  # noqa: BLE001 - surface, never crash Blender
            self.report({"ERROR"}, f"materialsdb-gui not reachable: {err}")
            return {"CANCELLED"}
        placeholders = sum(1 for layer in construction["layers"] if layer["placeholder"])
        self.report(
            {"INFO"},
            f"sent {len(construction['layers'])} layer(s) ({placeholders} model material) to the composer",
        )
        return {"FINISHED"}


class MATERIALSDB_PT_panel(bpy.types.Panel):
    bl_label = "materialsdb"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "materialsdb"

    def draw(self, context):
        running = _CLIENT is not None
        layout = self.layout
        layout.operator("materialsdb.start_server", text="Start server & open picker")
        if _SERVER_PROC is not None:
            layout.operator("materialsdb.stop_server", text="Stop server")
        url = _server_url()
        if url:
            layout.label(text=url)
        layout.operator("materialsdb.toggle_listener", text="Stop listener" if running else "Start listener")
        layout.operator("materialsdb.send_construction", text="Send type to composer")
        layout.label(text="listening" if running else "stopped", icon="LINKED" if running else "UNLINKED")


def register():
    bpy.utils.register_class(MATERIALSDB_Preferences)
    bpy.utils.register_class(MATERIALSDB_OT_toggle_listener)
    bpy.utils.register_class(MATERIALSDB_OT_apply_push)
    bpy.utils.register_class(MATERIALSDB_OT_send_construction)
    bpy.utils.register_class(MATERIALSDB_OT_start_server)
    bpy.utils.register_class(MATERIALSDB_OT_stop_server)
    bpy.utils.register_class(MATERIALSDB_PT_panel)


def unregister():
    global _CLIENT
    _CLIENT = None
    _kill_server()
    if bpy.app.timers.is_registered(_poll_timer):
        bpy.app.timers.unregister(_poll_timer)
    bpy.utils.unregister_class(MATERIALSDB_PT_panel)
    bpy.utils.unregister_class(MATERIALSDB_OT_stop_server)
    bpy.utils.unregister_class(MATERIALSDB_OT_start_server)
    bpy.utils.unregister_class(MATERIALSDB_OT_send_construction)
    bpy.utils.unregister_class(MATERIALSDB_OT_apply_push)
    bpy.utils.unregister_class(MATERIALSDB_OT_toggle_listener)
    bpy.utils.unregister_class(MATERIALSDB_Preferences)
